import React, { useState } from "react";
import Header from "../header/Header";
import Navbar from "../navbar/Navbar";
import Footer from "../footer/Footer";
import "./EventsPage.css";

// ─────────────────────────────────────────────────────────────
// UPCOMING EVENTS
// When backend is ready, replace this empty array by fetching
// from your API: GET /api/events?type=upcoming
// Each event object should have:
//   { id, title, date, time, location, category, description,
//     image, seats, seatsLeft }
// ─────────────────────────────────────────────────────────────
const upcomingEvents = [];

// ─────────────────────────────────────────────────────────────
// PAST EVENTS
// When backend is ready, replace this static array by fetching
// from your API: GET /api/events?type=past
// Each event object should have:
//   { id, title, date, location, category, description,
//     coverImage, attendees, photos: [ {url, caption}, ... ] }
// ─────────────────────────────────────────────────────────────
const pastEvents = [
  {
    id: 4,
    title: "Annual Graduation Ceremony 2024",
    date: "December 10, 2024",
    location: "Nehru Centre, Mumbai",
    category: "Ceremony",
    description:
      "Over 800 trainees received their certificates of completion, joined by industry partners and government dignitaries. The ceremony celebrated milestones achieved across all 36+ centres.",
    coverImage: "https://images.unsplash.com/photo-1523580494863-6f3031224c94?w=900&auto=format&fit=crop&q=80",
    attendees: 1200,
    photos: [
      { url: "https://images.unsplash.com/photo-1523580494863-6f3031224c94?w=800&auto=format&fit=crop&q=80", caption: "Certificate distribution ceremony" },
      { url: "https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=800&auto=format&fit=crop&q=80", caption: "Opening address by director" },
      { url: "https://images.unsplash.com/photo-1531482615713-2afd69097998?w=800&auto=format&fit=crop&q=80", caption: "Trainees on stage" },
      { url: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=800&auto=format&fit=crop&q=80", caption: "Guest of honour felicitation" },
    ],
  },
  {
    id: 5,
    title: "Digital Literacy Drive – Rural Centres",
    date: "October 5, 2024",
    location: "Nagpur & Nashik Centres",
    category: "Drive",
    description:
      "A two-day intensive digital literacy drive reaching over 500 rural youth across six ABVKVK centres. Sessions covered basic computing, internet safety, and digital payments.",
    coverImage: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=900&auto=format&fit=crop&q=80",
    attendees: 520,
    photos: [
      { url: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=800&auto=format&fit=crop&q=80", caption: "Hands-on computer training" },
      { url: "https://images.unsplash.com/photo-1531482615713-2afd69097998?w=800&auto=format&fit=crop&q=80", caption: "Rural youth learning digital skills" },
      { url: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&auto=format&fit=crop&q=80", caption: "Instructor-led session at Nagpur centre" },
    ],
  },
  {
    id: 6,
    title: "Placement Fair – Hospitality Sector",
    date: "September 14, 2024",
    location: "Hotel Taj, Aurangabad",
    category: "Placement",
    description:
      "Top hotel chains interviewed 300+ candidates from our Food & Beverage and Front Office programs. 78% of candidates received offer letters on the same day, marking our highest placement rate.",
    coverImage: "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?w=900&auto=format&fit=crop&q=80",
    attendees: 340,
    photos: [
      { url: "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?w=800&auto=format&fit=crop&q=80", caption: "Interview rounds in progress" },
      { url: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=800&auto=format&fit=crop&q=80", caption: "Offer letters being distributed" },
      { url: "https://images.unsplash.com/photo-1523580494863-6f3031224c94?w=800&auto=format&fit=crop&q=80", caption: "Panel of hospitality recruiters" },
      { url: "https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=800&auto=format&fit=crop&q=80", caption: "Selected candidates group photo" },
    ],
  },
  {
    id: 7,
    title: "Republic Day Skill Showcase",
    date: "January 26, 2024",
    location: "Chembur Training Centre",
    category: "Showcase",
    description:
      "Live demonstrations of automotive repair, tailoring, and IT skills by trainees for the public and press. The event drew significant media coverage and highlighted the impact of vocational education.",
    coverImage: "https://images.unsplash.com/photo-1531482615713-2afd69097998?w=900&auto=format&fit=crop&q=80",
    attendees: 680,
    photos: [
      { url: "https://images.unsplash.com/photo-1531482615713-2afd69097998?w=800&auto=format&fit=crop&q=80", caption: "Automotive repair live demo" },
      { url: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=800&auto=format&fit=crop&q=80", caption: "Tailoring skills exhibition" },
      { url: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&auto=format&fit=crop&q=80", caption: "IT skills demo booth" },
    ],
  },
];

const CATEGORY_COLORS = {
  Summit:    "#0f2463",
  Workshop:  "#10b981",
  Networking:"#6366f1",
  Ceremony:  "#ec4899",
  Drive:     "#14b8a6",
  Placement: "#f97316",
  Showcase:  "#8b5cf6",
};

export default function EventsPage() {
  const [lightbox, setLightbox] = useState(null); // { photos, index }

  const openLightbox = (photos, index = 0) => setLightbox({ photos, index });
  const closeLightbox = () => setLightbox(null);
  const prevPhoto = () => setLightbox(lb => ({ ...lb, index: (lb.index - 1 + lb.photos.length) % lb.photos.length }));
  const nextPhoto = () => setLightbox(lb => ({ ...lb, index: (lb.index + 1) % lb.photos.length }));

  return (
    <div className="events-page">
      <Header />
      <Navbar />

      {/* ── Hero ─────────────────────────────────── */}
      <section className="ep-hero">
        <div className="ep-hero__inner">
          <div>
            <div className="ep-eyebrow">Events &amp; Programmes</div>
            <h1 className="ep-hero__title">Where Skills Meet<br />Opportunity</h1>
            <p className="ep-hero__sub">
              Summits, placement drives, and community events across all 36+ CII centres — bringing industry and youth together.
            </p>
          </div>
          <div className="ep-hero__stats">
            <div className="ep-stat">
              <span className="ep-stat__num">120+</span>
              <span className="ep-stat__label">Events Hosted</span>
            </div>
            <div className="ep-stat">
              <span className="ep-stat__num">50K+</span>
              <span className="ep-stat__label">Attendees</span>
            </div>
            <div className="ep-stat">
              <span className="ep-stat__num">36+</span>
              <span className="ep-stat__label">Centres</span>
            </div>
          </div>
        </div>
      </section>

      {/* ── Upcoming Events ───────────────────────── */}
      <section className="ep-section" id="upcoming">
        <div className="ep-section__inner">
          <div className="ep-eyebrow">Don't Miss Out</div>
          <h2 className="ep-section__title">Upcoming Events</h2>

          {upcomingEvents.length === 0 ? (
            <div className="ep-empty">
              <div className="ep-empty__icon">📅</div>
              <h3 className="ep-empty__heading">No Upcoming Events</h3>
              <p className="ep-empty__text">
                There are no events scheduled at the moment.<br />
                Check back soon — new events are added regularly.
              </p>
            </div>
          ) : (
            <div className="ep-upcoming-grid">
              {upcomingEvents.map((event) => (
                <UpcomingCard key={event.id} event={event} />
              ))}
            </div>
          )}
        </div>
      </section>

      <div className="ep-divider-wrap"><hr className="ep-divider" /></div>

      {/* ── Past Events ───────────────────────────── */}
      <section className="ep-section ep-section--grey" id="past">
        <div className="ep-section__inner">
          <div className="ep-eyebrow">Highlights</div>
          <h2 className="ep-section__title">Past Events</h2>

          <div className="ep-past-list">
            {pastEvents.map((event, idx) => (
              <PastCard
                key={event.id}
                event={event}
                reverse={idx % 2 !== 0}
                onViewPhotos={() => openLightbox(event.photos, 0)}
              />
            ))}
          </div>
        </div>
      </section>

      {/* ── Lightbox ─────────────────────────────── */}
      {lightbox && (
        <div className="ep-lightbox" onClick={closeLightbox}>
          <div className="ep-lightbox__box" onClick={e => e.stopPropagation()}>
            <button className="ep-lightbox__close" onClick={closeLightbox}>✕</button>
            <img
              src={lightbox.photos[lightbox.index].url}
              alt={lightbox.photos[lightbox.index].caption}
              className="ep-lightbox__img"
            />
            <div className="ep-lightbox__caption">
              {lightbox.photos[lightbox.index].caption}
            </div>
            <div className="ep-lightbox__controls">
              <button className="ep-lightbox__btn" onClick={prevPhoto}>‹</button>
              <span className="ep-lightbox__counter">
                {lightbox.index + 1} / {lightbox.photos.length}
              </span>
              <button className="ep-lightbox__btn" onClick={nextPhoto}>›</button>
            </div>
            {/* Thumbnail strip */}
            <div className="ep-lightbox__thumbs">
              {lightbox.photos.map((p, i) => (
                <img
                  key={i}
                  src={p.url}
                  alt={p.caption}
                  className={`ep-lightbox__thumb${i === lightbox.index ? " ep-lightbox__thumb--active" : ""}`}
                  onClick={() => setLightbox(lb => ({ ...lb, index: i }))}
                />
              ))}
            </div>
          </div>
        </div>
      )}

      <Footer />
    </div>
  );
}

/* ── Upcoming Card (ready for backend data) ──────── */
function UpcomingCard({ event }) {
  const catColor = CATEGORY_COLORS[event.category] || "#0f2463";
  return (
    <div className="ep-ucard">
      <div className="ep-ucard__img-wrap">
        <img src={event.image} alt={event.title} className="ep-ucard__img" />
        <span className="ep-ucard__cat" style={{ background: catColor }}>{event.category}</span>
      </div>
      <div className="ep-ucard__body">
        <div className="ep-ucard__date-row">
          <span>{event.date}</span>
          <span className="ep-ucard__dot" />
          <span>{event.time}</span>
        </div>
        <h3 className="ep-ucard__title">{event.title}</h3>
        <p className="ep-ucard__desc">{event.description}</p>
        <div className="ep-ucard__location"><PinIcon /> {event.location}</div>
        <div className="ep-ucard__seats">
          <strong>{event.seatsLeft}</strong> seats remaining of {event.seats}
        </div>
      </div>
    </div>
  );
}

/* ── Past Event Card (full-width alternating) ─────── */
function PastCard({ event, reverse, onViewPhotos }) {
  const catColor = CATEGORY_COLORS[event.category] || "#0f2463";
  return (
    <div className={`ep-pcard${reverse ? " ep-pcard--reverse" : ""}`}>
      {/* Image side */}
      <div className="ep-pcard__img-wrap">
        <img src={event.coverImage} alt={event.title} className="ep-pcard__img" />
        <span className="ep-pcard__cat" style={{ background: catColor }}>{event.category}</span>
        {/* View Photos overlay button */}
        <button className="ep-pcard__photo-btn" onClick={onViewPhotos}>
          <GalleryIcon />
          View {event.photos.length} Photos
        </button>
      </div>

      {/* Content side */}
      <div className="ep-pcard__body">
        <div className="ep-pcard__date">{event.date}</div>
        <h3 className="ep-pcard__title">{event.title}</h3>
        <p className="ep-pcard__desc">{event.description}</p>

        <div className="ep-pcard__meta">
          <div className="ep-pcard__meta-item">
            <PinIcon />
            <span>{event.location}</span>
          </div>
          <div className="ep-pcard__meta-item">
            <PeopleIcon />
            <span><strong>{event.attendees.toLocaleString()}</strong> attended</span>
          </div>
        </div>

        <button className="ep-pcard__gallery-btn" onClick={onViewPhotos}>
          <GalleryIcon /> View Event Photos
        </button>
      </div>
    </div>
  );
}

/* ── Icons ───────────────────────────────────────── */
const PinIcon = () => (
  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" /><circle cx="12" cy="10" r="3" />
  </svg>
);
const PeopleIcon = () => (
  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" />
    <path d="M23 21v-2a4 4 0 0 0-3-3.87" /><path d="M16 3.13a4 4 0 0 1 0 7.75" />
  </svg>
);
const GalleryIcon = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <rect x="3" y="3" width="18" height="18" rx="2" />
    <circle cx="8.5" cy="8.5" r="1.5" />
    <polyline points="21 15 16 10 5 21" />
  </svg>
);
