import React, { useState } from "react";
import { Users } from "lucide-react";
import SectionCard from "../../shared/SectionCard/SectionCard";
import Sidebar from "../../layout/Sidebar/Sidebar";
import Topbar from "../../layout/Topbar/Topbar";
import "./CandidateManagement.css";

/**
 * CandidateManagement
 *
 * Staff page for managing candidates.
 * This is a placeholder component that can be expanded with real functionality.
 */
const CandidateManagement = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [searchValue, setSearchValue] = useState('');

  return (
    <div className="staff-dashboard">
      <Topbar
        user={{ name: "Staff Admin" }}
        hasUnreadNotifications={true}
        onMenuToggle={() => setSidebarOpen((o) => !o)}
        onSearch={setSearchValue}
      />

      <div className="staff-dashboard__content">
        <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />

        <div className="staff-dashboard__main">
          <main className="staff-dashboard__body">
            <div className="candidate-management">
      <SectionCard title="Candidate Management" className="candidate-management__card">
        <div className="candidate-management__content">
          <Users size={48} className="candidate-management__icon" />
          <h2>Candidate Management</h2>
          <p>Manage and view all candidates in the system.</p>
          <p className="candidate-management__placeholder-note">
            This page is under development. Content will be added soon.
          </p>
        </div>
      </SectionCard>
    </div>
          </main>
        </div>
      </div>
    </div>
  );
};

export default CandidateManagement;