// ============================================================================
// JobFiltersBar.jsx
// ----------------------------------------------------------------------------
// The "Filters | Location | Type | Roles | Sort by" pill row.
//
// This is UI scaffolding: the dropdowns don't open a menu yet (no design
// reference was given for their open state), but each button already
// carries the data + handler wiring you'll need:
//
// BACKEND / STATE NOTE: lift real filter state up into JobOpportunities.jsx
// (e.g. { location, type, role, sort }), pass the active value + an
// onChange-style callback down as props here, and re-fetch
// GET /api/candidates/:id/job-opportunities?location=&type=&role=&sort=
// whenever a filter changes. The `onOpenFilters` / `onOpenDropdown` props
// below are where you'd toggle an actual dropdown/menu component.
// ============================================================================

import React from "react";
import Icon from "../../../shared/Icon/Icon";
import { jobFilterOptions } from "../../../../../data/jobOpportunitiesData";
import "./JobFiltersBar.css";

const JobFiltersBar = ({
  hasActiveIndicator = jobFilterOptions.hasActiveIndicator,
  filters = jobFilterOptions.filters,
  sort = jobFilterOptions.sort,
  onOpenFilters,
  onOpenDropdown,
}) => {
  return (
    <div className="job-filters-bar">
      <button
        type="button"
        className="job-filters-bar__filters-pill"
        onClick={() => onOpenFilters && onOpenFilters()}
      >
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none">
          <path d={ICON_PATHS.filter} fill="currentColor" />
        </svg>
        Filters
        {hasActiveIndicator && <span className="job-filters-bar__dot" aria-hidden="true" />}
      </button>

      {filters.map((filter) => (
        <button
          key={filter.id}
          type="button"
          className="job-filters-bar__dropdown-pill"
          onClick={() => onOpenDropdown && onOpenDropdown(filter.id)}
        >
          {filter.label}
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
            <path d={ICON_PATHS.chevronDown} fill="currentColor" />
          </svg>
        </button>
      ))}

      {sort && (
        <button
          type="button"
          className="job-filters-bar__dropdown-pill"
          onClick={() => onOpenDropdown && onOpenDropdown(sort.id)}
        >
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
            <path d={ICON_PATHS.sort} fill="currentColor" />
          </svg>
          {sort.label}
        </button>
      )}
    </div>
  );
};

export default JobFiltersBar;
